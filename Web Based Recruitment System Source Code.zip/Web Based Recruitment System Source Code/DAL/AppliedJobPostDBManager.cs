﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOL;
using System.Data;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace DAL
{
   public  class AppliedJobPostDBManager
    {

        public static readonly string connString = string.Empty;

        static AppliedJobPostDBManager()
        {
            connString = ConfigurationManager.ConnectionStrings["dbString"].ConnectionString;
        }

        public static List<AppliedJobPost> GetAllAppliedJobPost()
        {
            List<AppliedJobPost> allAppliedJobPost = new List<AppliedJobPost>();

            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            String query = "Select * from applied_job";
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();

            try
            {
                da.Fill(ds);
                DataRowCollection rows = ds.Tables[0].Rows;
                foreach (DataRow row in rows)
                {
                    AppliedJobPost theAppliedJobPost = new AppliedJobPost();
                    theAppliedJobPost.appliedId = int.Parse(row["appliedId"].ToString());
                    theAppliedJobPost.status = bool.Parse(row["status"].ToString());
                    theAppliedJobPost.candidateId = int.Parse(row["candidateId"].ToString());
                    theAppliedJobPost.jobId = int.Parse(row["jobId"].ToString());
                    allAppliedJobPost.Add(theAppliedJobPost);

                }

            }
            catch (MySqlException e)
            {
                string msg = e.Message;
            }


            return allAppliedJobPost;
        }


        public static AppliedJobPost GetAppliedJobPostById(int id)
        {
            AppliedJobPost theAppliedJobPost = new AppliedJobPost();
            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            string query = "select * from applied_job where appliedId=" + id;
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();
            try
            {
                da.Fill(ds);
                DataRowCollection rows = ds.Tables[0].Rows;
                foreach (DataRow row in rows)
                {
                    theAppliedJobPost.appliedId = int.Parse(row["appliedId"].ToString());
                    theAppliedJobPost.status = bool.Parse(row["status"].ToString());
                    theAppliedJobPost.candidateId = int.Parse(row["candidateId"].ToString());
                    theAppliedJobPost.jobId = int.Parse(row["jobId"].ToString());
                }

            }
            catch (MySqlException e)
            {
                string msg = e.Message;
            }


            return theAppliedJobPost;
        }

        public static bool Insert(AppliedJobPost newAppliedJobPost)
        {

            bool status = false;
            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            string query = "select * from applied_job";
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();
            try
            {
                MySqlCommandBuilder cmdbuilder = new MySqlCommandBuilder(da);
                da.Fill(ds);
                DataRow row = ds.Tables[0].NewRow();
                row["status"] = newAppliedJobPost.status;
                row["candidateId"] = newAppliedJobPost.candidateId;
                row["jobId"] = newAppliedJobPost.jobId;
                ds.Tables[0].Rows.Add(row);
                da.Update(ds);
                status = true;



            }
            catch (MySqlException e)
            {

            }

            return status;
        }

        public static bool update(AppliedJobPost theAppliedJobPost)
        {
            bool status = false;
            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = "select * from applied_job";
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();
            try
            {
                MySqlCommandBuilder cmdbuilder = new MySqlCommandBuilder(da);
                da.Fill(ds);
                DataColumn[] keyColumns = new DataColumn[1];
                keyColumns[0] = ds.Tables[0].Columns["appliedId"];
                ds.Tables[0].PrimaryKey = keyColumns;
                DataRow datarow = ds.Tables[0].Rows.Find(theAppliedJobPost.appliedId);
                datarow["status"] = theAppliedJobPost.status;
                datarow["candidateId"] = theAppliedJobPost.candidateId;
                datarow["jobId"] = theAppliedJobPost.jobId;
                
                da.Update(ds);
                status = true;


            }
            catch (MySqlException e)
            {
                string msg = e.Message;
            }

            return status;
        }

        public static bool Delete(int id)
        {
            bool status = false;
            try
            {
                using (MySqlConnection con = new MySqlConnection(connString))
                {
                    if (con.State == ConnectionState.Closed)
                    {
                        con.Open();
                    }
                    string query = "Delete from applied_job where appliedId=@id";
                    MySqlCommand cmd = new MySqlCommand(query, con);
                    cmd.Parameters.Add(new MySqlParameter("@id", id));
                    cmd.ExecuteNonQuery();
                    con.Close();
                    status = true;

                }

            }
            catch (MySqlException e)
            {
                string msg = e.Message;
            }

            return status;
        }


    }
}

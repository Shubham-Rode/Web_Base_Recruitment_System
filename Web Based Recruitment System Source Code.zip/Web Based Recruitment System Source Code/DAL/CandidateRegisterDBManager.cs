﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOL;
using System.Data;
using MySql.Data.MySqlClient;
using System.Configuration;


namespace DAL
{
    public class CandidateRegisterDBManager
    {
        public static readonly string connString = string.Empty;

        static CandidateRegisterDBManager()
        {
            connString = ConfigurationManager.ConnectionStrings["dbString"].ConnectionString;
        }

        public static List<CandidateRegister> GetAllCandidateRegister()
        {
            List<CandidateRegister> allCandidateRegister = new List<CandidateRegister>();

            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            String query = "Select * from candidate_register";
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();

            try
            {
                da.Fill(ds);
                DataRowCollection rows = ds.Tables[0].Rows;
                foreach (DataRow row in rows)
                {
                    CandidateRegister theCandidateRegister = new CandidateRegister();
                    theCandidateRegister.candidateId = int.Parse(row["candidateId"].ToString());
                    theCandidateRegister.firstName = row["firstName"].ToString();
                    theCandidateRegister.lastName = row["lastName"].ToString();
                    theCandidateRegister.email = row["email"].ToString();
                    theCandidateRegister.password = row["password"].ToString();
                    theCandidateRegister.gender = row["gender"].ToString();
                    theCandidateRegister.dob = DateTime.Parse(row["dob"].ToString());
                    theCandidateRegister.canAddr = row["canAddr"].ToString();
                    theCandidateRegister.phoneNum = row["phoneNum"].ToString();
                    theCandidateRegister.state = row["state"].ToString();
                    theCandidateRegister.city = row["city"].ToString();
                    theCandidateRegister.altEmail = row["altEmail"].ToString(); 
                    theCandidateRegister.pincode = int.Parse(row["pincode"].ToString());
                    theCandidateRegister.schoolName = row["schoolName"].ToString();
                    theCandidateRegister.tenthBoardname = row["tenthBoardname"].ToString();
                    theCandidateRegister.schoolPercentage = double.Parse(row["schoolPercentage"].ToString()); 
                    theCandidateRegister.schoolPassingyear = int.Parse(row["schoolPassingyear"].ToString());
                    theCandidateRegister.hscCollegeName = row["hscCollegeName"].ToString();
                    theCandidateRegister.hscBoardName = row["hscBoardName"].ToString();
                    theCandidateRegister.hscPercentage = double.Parse(row["hscPercentage"].ToString());
                    theCandidateRegister.hscPassingyear = int.Parse(row["hscPassingyear"].ToString());
                    theCandidateRegister.collegeName = row["collegeName"].ToString();
                    theCandidateRegister.universityName = row["universityName"].ToString();
                    theCandidateRegister.stream = row["stream"].ToString();
                    theCandidateRegister.graduationPercentage = double.Parse(row["graduationPercentage"].ToString());
                    theCandidateRegister.graduationPassingYear = int.Parse(row["graduationPassingYear"].ToString());
                    theCandidateRegister.projectTitle = row["projectTitle"].ToString();
                    theCandidateRegister.projectDetails = row["projectDetails"].ToString();
                    theCandidateRegister.certification = row["certification"].ToString();

                    allCandidateRegister.Add(theCandidateRegister);

                }

            }
            catch (MySqlException e)
            {
                string msg = e.Message;
            }


            return allCandidateRegister;
        }


        public static CandidateRegister GetCandidateRegisterById(int id)
        {
            CandidateRegister theCandidateRegister = new CandidateRegister();
            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            string query = "select * from candidate_register where candidateId=" + id;
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();
            try
            {
                da.Fill(ds);
                DataRowCollection rows = ds.Tables[0].Rows;
                foreach (DataRow row in rows)
                {
                    theCandidateRegister.candidateId = int.Parse(row["candidateId"].ToString());
                    theCandidateRegister.firstName = row["firstName"].ToString();
                    theCandidateRegister.lastName = row["lastName"].ToString();
                    theCandidateRegister.email = row["email"].ToString();
                    theCandidateRegister.password = row["password"].ToString();
                    theCandidateRegister.gender = row["gender"].ToString();
                    theCandidateRegister.dob = DateTime.Parse(row["dob"].ToString());
                    theCandidateRegister.canAddr = row["canAddr"].ToString();
                    theCandidateRegister.phoneNum = row["phoneNum"].ToString();
                    theCandidateRegister.state = row["state"].ToString();
                    theCandidateRegister.city = row["city"].ToString();
                    theCandidateRegister.altEmail = row["altEmail"].ToString();
                    theCandidateRegister.pincode = int.Parse(row["pincode"].ToString());
                    theCandidateRegister.schoolName = row["schoolName"].ToString();
                    theCandidateRegister.tenthBoardname = row["tenthBoardname"].ToString();
                    theCandidateRegister.schoolPercentage = double.Parse(row["schoolPercentage"].ToString());
                    theCandidateRegister.schoolPassingyear = int.Parse(row["schoolPassingyear"].ToString());
                    theCandidateRegister.hscCollegeName = row["hscCollegeName"].ToString();
                    theCandidateRegister.hscBoardName = row["hscBoardName"].ToString();
                    theCandidateRegister.hscPercentage = double.Parse(row["hscPercentage"].ToString());
                    theCandidateRegister.hscPassingyear = int.Parse(row["hscPassingyear"].ToString());
                    theCandidateRegister.collegeName = row["collegeName"].ToString();
                    theCandidateRegister.universityName = row["universityName"].ToString();
                    theCandidateRegister.stream = row["stream"].ToString();
                    theCandidateRegister.graduationPercentage = double.Parse(row["graduationPercentage"].ToString());
                    theCandidateRegister.graduationPassingYear = int.Parse(row["graduationPassingYear"].ToString());
                    theCandidateRegister.projectTitle = row["projectTitle"].ToString();
                    theCandidateRegister.projectDetails = row["projectDetails"].ToString();
                    theCandidateRegister.certification = row["certification"].ToString();
                }

            }
            catch (MySqlException e)
            {
                string msg = e.Message;
            }


            return theCandidateRegister;
        }


        public static bool Insert(CandidateRegister newCandidateRegister)
        {

            bool status = false;
            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            string query = "select * from candidate_register";
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();
            try
            {
                MySqlCommandBuilder cmdbuilder = new MySqlCommandBuilder(da);
                da.Fill(ds);
                DataRow row = ds.Tables[0].NewRow();
                row["firstName"] = newCandidateRegister.firstName;
                row["lastName"] = newCandidateRegister.lastName;
                row["email"] = newCandidateRegister.email;
                row["password"] = newCandidateRegister.password;
                row["gender"] = newCandidateRegister.gender;
                row["dob"] = newCandidateRegister.dob;
                row["canAddr"] = newCandidateRegister.canAddr;
                row["phoneNum"] = newCandidateRegister.phoneNum;
                row["state"] = newCandidateRegister.state;
                row["city"] = newCandidateRegister.city;
                row["altEmail"] = newCandidateRegister.altEmail;
                row["pincode"] = newCandidateRegister.pincode;
                row["schoolName"] = newCandidateRegister.schoolName;
                row["tenthBoardname"] = newCandidateRegister.tenthBoardname;
                row["schoolPercentage"] = newCandidateRegister.schoolPercentage;
                row["schoolPassingyear"] = newCandidateRegister.schoolPassingyear;
                row["hscCollegeName"] = newCandidateRegister.hscCollegeName;
                row["hscBoardName"] = newCandidateRegister.hscBoardName;
                row["hscPercentage"] = newCandidateRegister.hscPercentage;
                row["hscPassingyear"] = newCandidateRegister.hscPassingyear;
                row["collegeName"] = newCandidateRegister.collegeName;
                row["universityName"] = newCandidateRegister.universityName;
                row["stream"] = newCandidateRegister.stream;
                row["graduationPercentage"] = newCandidateRegister.graduationPercentage;
                row["graduationPassingYear"] = newCandidateRegister.graduationPassingYear;
                row["projectTitle"] = newCandidateRegister.projectTitle;
                row["projectDetails"] = newCandidateRegister.projectDetails;
                row["certification"] = newCandidateRegister.certification;
                ds.Tables[0].Rows.Add(row);
                da.Update(ds);
                status = true;



            }
            catch (MySqlException e)
            {

            }

            return status;
        }

        public static bool update(CandidateRegister theCandidateRegister)
        {
            bool status = false;
            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = "select * from candidate_register";
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();
            try
            {
                MySqlCommandBuilder cmdbuilder = new MySqlCommandBuilder(da);
                da.Fill(ds);
                DataColumn[] keyColumns = new DataColumn[1];
                keyColumns[0] = ds.Tables[0].Columns["candidateId"];
                ds.Tables[0].PrimaryKey = keyColumns;
                DataRow datarow = ds.Tables[0].Rows.Find(theCandidateRegister.candidateId);
                datarow["firstName"] = theCandidateRegister.firstName;
                datarow["lastName"] = theCandidateRegister.lastName;
                datarow["email"] = theCandidateRegister.email;
                datarow["password"] = theCandidateRegister.password;
                datarow["gender"] = theCandidateRegister.gender;
                datarow["dob"] = theCandidateRegister.dob;
                datarow["canAddr"] = theCandidateRegister.canAddr;
                datarow["phoneNum"] = theCandidateRegister.phoneNum;
                datarow["state"] = theCandidateRegister.state;
                datarow["city"] = theCandidateRegister.city;
                datarow["altEmail"] = theCandidateRegister.altEmail;
                datarow["pincode"] = theCandidateRegister.pincode;
                datarow["schoolName"] = theCandidateRegister.schoolName;
                datarow["tenthBoardname"] = theCandidateRegister.tenthBoardname;
                datarow["schoolPercentage"] = theCandidateRegister.schoolPercentage;
                datarow["schoolPassingyear"] = theCandidateRegister.schoolPassingyear;
                datarow["hscCollegeName"] = theCandidateRegister.hscCollegeName;
                datarow["hscBoardName"] = theCandidateRegister.hscBoardName;
                datarow["hscPercentage"] = theCandidateRegister.hscPercentage;
                datarow["hscPassingyear"] = theCandidateRegister.hscPassingyear;
                datarow["collegeName"] = theCandidateRegister.collegeName;
                datarow["universityName"] = theCandidateRegister.universityName;
                datarow["stream"] = theCandidateRegister.stream;
                datarow["graduationPercentage"] = theCandidateRegister.graduationPercentage;
                datarow["graduationPassingYear"] = theCandidateRegister.graduationPassingYear;
                datarow["projectTitle"] = theCandidateRegister.projectTitle;
                datarow["projectDetails"] = theCandidateRegister.projectDetails;
                datarow["certification"] = theCandidateRegister.certification;
                da.Update(ds);
                status = true;


            }
            catch (MySqlException e)
            {
                string msg = e.Message;
            }

            return status;
        }

        public static bool Delete(int id)
        {
            bool status = false;
            try
            {
                using (MySqlConnection con = new MySqlConnection(connString))
                {
                    if (con.State == ConnectionState.Closed)
                    {
                        con.Open();
                    }
                    string query = "Delete from candidate_register where candidateId=@id";
                    MySqlCommand cmd = new MySqlCommand(query, con);
                    cmd.Parameters.Add(new MySqlParameter("@id", id));
                    cmd.ExecuteNonQuery();
                    con.Close();
                    status = true;

                }

            }
            catch (MySqlException e)
            {
                string msg = e.Message;
            }

            return status;
        }



        public static CandidateRegister GetCandidateByEmailAndPassword (String email,String password)
        {
            CandidateRegister theCandidateRegister = new CandidateRegister();
            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            string query = "select * from candidate_register where email='" + email + "' AND password='"+password+"'";
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();
            try
            {
                da.Fill(ds);
                DataRowCollection rows = ds.Tables[0].Rows;
                foreach (DataRow row in rows)
                {
                    theCandidateRegister.candidateId = int.Parse(row["candidateId"].ToString());
                    theCandidateRegister.firstName = row["firstName"].ToString();
                    theCandidateRegister.lastName = row["lastName"].ToString();
                    theCandidateRegister.email = row["email"].ToString();
                    theCandidateRegister.password = row["password"].ToString();
                    theCandidateRegister.gender = row["gender"].ToString();
                    theCandidateRegister.dob = DateTime.Parse(row["dob"].ToString());
                    theCandidateRegister.canAddr = row["canAddr"].ToString();
                    theCandidateRegister.phoneNum = row["phoneNum"].ToString();
                    theCandidateRegister.state = row["state"].ToString();
                    theCandidateRegister.city = row["city"].ToString();
                    theCandidateRegister.altEmail = row["altEmail"].ToString();
                    theCandidateRegister.pincode = int.Parse(row["pincode"].ToString());
                    theCandidateRegister.schoolName = row["schoolName"].ToString();
                    theCandidateRegister.tenthBoardname = row["tenthBoardname"].ToString();
                    theCandidateRegister.schoolPercentage = double.Parse(row["schoolPercentage"].ToString());
                    theCandidateRegister.schoolPassingyear = int.Parse(row["schoolPassingyear"].ToString());
                    theCandidateRegister.hscCollegeName = row["hscCollegeName"].ToString();
                    theCandidateRegister.hscBoardName = row["hscBoardName"].ToString();
                    theCandidateRegister.hscPercentage = double.Parse(row["hscPercentage"].ToString());
                    theCandidateRegister.hscPassingyear = int.Parse(row["hscPassingyear"].ToString());
                    theCandidateRegister.collegeName = row["collegeName"].ToString();
                    theCandidateRegister.universityName = row["universityName"].ToString();
                    theCandidateRegister.stream = row["stream"].ToString();
                    theCandidateRegister.graduationPercentage = double.Parse(row["graduationPercentage"].ToString());
                    theCandidateRegister.graduationPassingYear = int.Parse(row["graduationPassingYear"].ToString());
                    theCandidateRegister.projectTitle = row["projectTitle"].ToString();
                    theCandidateRegister.projectDetails = row["projectDetails"].ToString();
                    theCandidateRegister.certification = row["certification"].ToString();
                }

            }
            catch (MySqlException e)
            {
                string msg = e.Message;
            }


            return theCandidateRegister;

        }



    }
}

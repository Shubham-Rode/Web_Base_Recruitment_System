﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOL;
using System.Data;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace DAL
{
    public class AdminDBManager
    {
        public static readonly string connString = string.Empty;

        static AdminDBManager()
        {
            connString = ConfigurationManager.ConnectionStrings["dbString"].ConnectionString;
        }

        public static List<Admin> GetAllAdmin()
        {
            List<Admin> allAdmin = new List<Admin>();

            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            String query = "Select * from project_admin";
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();

            try
            {
                da.Fill(ds);
                DataRowCollection rows = ds.Tables[0].Rows;
                foreach (DataRow row in rows)
                {
                    Admin theAdmin = new Admin();
                    theAdmin.adminId = int.Parse(row["adminId"].ToString());
                    theAdmin.firstName = row["firstName"].ToString();
                    theAdmin.lastName = row["lastName"].ToString();
                    theAdmin.email = row["email"].ToString();
                    theAdmin.password = row["password"].ToString();
                    allAdmin.Add(theAdmin);

                }

            }
            catch (MySqlException e)
            {
                string msg = e.Message;
            }


            return allAdmin;
        }

        public static Admin GetAdminById(int id)
        {
            Admin theAdmin = new Admin();
            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            string query = "select * from project_admin where adminId=" + id;
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();
            try
            {
                da.Fill(ds);
                DataRowCollection rows = ds.Tables[0].Rows;
                foreach (DataRow row in rows)
                {
                    theAdmin.adminId = int.Parse(row["adminId"].ToString());
                    theAdmin.firstName = row["firstName"].ToString();
                    theAdmin.lastName = row["lastName"].ToString();
                    theAdmin.email = row["email"].ToString();
                    theAdmin.password = row["password"].ToString();

                }

            }
            catch (MySqlException e)
            {
                string msg = e.Message;
            }


            return theAdmin;
        }

        public static bool Insert(Admin newAdmin)
        {

            bool status = false;
            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            string query = "select * from project_admin";
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();
            try
            {
                MySqlCommandBuilder cmdbuilder = new MySqlCommandBuilder(da);
                da.Fill(ds);
                DataRow row = ds.Tables[0].NewRow();
                row["firstName"] = newAdmin.firstName;
                row["lastName"] = newAdmin.lastName;
                row["email"] = newAdmin.email;
                row["password"] = newAdmin.password;
                ds.Tables[0].Rows.Add(row);
                da.Update(ds);
                status = true;



            }
            catch (MySqlException e)
            {

            }

            return status;
        }

        public static bool update(Admin theAdmin)
        {
            bool status = false;
            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = "select * from project_admin";
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();
            try
            {
                MySqlCommandBuilder cmdbuilder = new MySqlCommandBuilder(da);
                da.Fill(ds);
                DataColumn[] keyColumns = new DataColumn[1];
                keyColumns[0] = ds.Tables[0].Columns["adminId"];
                ds.Tables[0].PrimaryKey = keyColumns;
                DataRow datarow = ds.Tables[0].Rows.Find(theAdmin.adminId);
                datarow["firstName"] = theAdmin.firstName;
                datarow["lastName"] = theAdmin.lastName;
                datarow["email"] = theAdmin.email;
                datarow["password"] = theAdmin.password;
                da.Update(ds);
                status = true;


            }
            catch (MySqlException e)
            {
                string msg = e.Message;
            }

            return status;
        }

        public static bool Delete(int id)
        {
            bool status = false;
            try
            {
                using (MySqlConnection con = new MySqlConnection(connString))
                {
                    if (con.State == ConnectionState.Closed)
                    {
                        con.Open();
                    }
                    string query = "Delete from project_admin where adminID=@id";
                    MySqlCommand cmd = new MySqlCommand(query, con);
                    cmd.Parameters.Add(new MySqlParameter("@id", id));
                    cmd.ExecuteNonQuery();
                    con.Close();
                    status = true;

                }

            }
            catch (MySqlException e)
            {
                string msg = e.Message;
            }

            return status;
        }


        public static Admin GetRecruiterByEmailAndPassword(String email,String pass)
        {


            Admin theAdmin = new Admin();
            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            string query = "select * from project_admin where email='" + email + "' AND password='" + pass + "'";
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();
            try
            {
                da.Fill(ds);
                DataRowCollection rows = ds.Tables[0].Rows;
                foreach (DataRow row in rows)
                {
                    theAdmin.adminId = int.Parse(row["adminId"].ToString());
                    theAdmin.firstName = row["firstName"].ToString();
                    theAdmin.lastName = row["lastName"].ToString();
                    theAdmin.email = row["email"].ToString();
                    theAdmin.password = row["password"].ToString();

                }

            }
            catch (MySqlException e)
            {
                string msg = e.Message;
            }


            return theAdmin;

        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BLL;
using BOL;

namespace webbaserecruitment.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult canlogin()
        {
            return View();
        }

        [HttpPost]
        public ActionResult canlogin(String user,String pass)
        {
           // CandidateRegister candidateLogin = new CandidateRegister { email=user,password=pass};

            CandidateRegister candidateLogin = CandidateRegisterBusinessManager.GetByEmailAndPassword(user, pass);
            // this.ViewData["canLogin"] = candidateLogin;
            Session["canLogin"] = candidateLogin;
            if (candidateLogin.city != null)
            {
                return this.RedirectToAction("canhome", "CandidateRegister");
            }
            else
            {
                return this.RedirectToAction("wrongpass", "home");

            }
        }

        public ActionResult wrongpass()
        {
            return View();

        }

        public ActionResult reglogin()
        {
            return View();
           
        }

        [HttpPost]
        public ActionResult reglogin(String user, String pass)
        {

            RecruiterRegister recruitmentLogin = RecruiterRegisterBusinessManager.GetByEmailAndPassword(user, pass);

            Session["regLogin"] = recruitmentLogin;

            if (recruitmentLogin.firstName != null)
            {

                return this.RedirectToAction("recruitmentHome", "recruiterRegister");
            }
            else
            {
                return this.RedirectToAction("recruitmentwrongpass", "home");

            }
        }

        public ActionResult recruitmentwrongpass()
        {
            return View();

        }

        public ActionResult adlogin()
        {
            return View();
        }

        [HttpPost]
        public ActionResult adlogin(String user, String pass)
        {

            Admin adminLogin = AdminBusinessManager.GetByEmailAndPassword(user, pass);

            TempData["adLogin"] = adminLogin;
            if(adminLogin.firstName!=null)
            { 
                return this.RedirectToAction("adhome", "Admin");
            }
            else
            {
                return this.RedirectToAction("adminwrongpass", "home");

            }
        }

        public ActionResult adminwrongpass()
        {
            return View();
        }

    }
}

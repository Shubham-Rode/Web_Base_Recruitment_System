﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BLL;
using BOL;


namespace webbaserecruitment.Controllers
{
    public class CandidateRegisterController : Controller
    {


        public ActionResult canhome()
        {
            if (Session["canLogin"] != null)
            {
                // location = (LocationByAddressReply)TempData["myObject"];
                CandidateRegister can = new CandidateRegister();
                can = (CandidateRegister)Session["canLogin"];

                this.ViewData["can"] = can;
                return View();
            }
            else
            {
                return null;
            }


        }

        [HttpPost]
        public ActionResult canhome(String title,String city)
        {

            List<RecruiterJobPost> TitleAndCityWiseJobs = RecruiterJobPostBusinessManager.GetAllRecruiterJobPostByTitleAndCity(title, city);

            Session["JobByTitleAndCity"] = TitleAndCityWiseJobs;

            CandidateRegister can = new CandidateRegister();
            can = (CandidateRegister)Session["canLogin"];

            this.ViewData["can"] = can;

            return this.RedirectToAction("SearchByTitleAndCity", "RecruiterJobPost");



        }

        // GET: CandidateRegister
        public ActionResult Index()
        {
            List<CandidateRegister> allCandidateRegister = CandidateRegisterBusinessManager.GetAllCandidateRegister();
            this.ViewData["candidateRegister"] = allCandidateRegister;
            return View();
        }



        

        public ActionResult Details(int id)
        {
            CandidateRegister theCandidateRegister = CandidateRegisterBusinessManager.GetById(id);

            return View(theCandidateRegister);
        }

        public ActionResult Insert()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Insert(string firstName, string lastName, string email, string password,
                string gender, DateTime dob , string canAddr, string phoneNum, string state,
                string city, string altEmail, int pincode, string schoolName, string tenthBoardname,
                double schoolPercentage, int schoolPassingyear, string hscCollegeName, string hscBoardName,
                double hscPercentage, int hscPassingyear, string collegeName, string universityName, 
                 string stream, double graduationPercentage, int graduationPassingYear, string projectTitle,
                string projectDetails,string certification)
        {
            CandidateRegister theCandidateRegister = new CandidateRegister 
              { firstName = firstName, lastName = lastName, 
                email = email, password = password, gender = gender, dob = dob,
                canAddr = canAddr, phoneNum = phoneNum, state = state, city = city,
                altEmail = altEmail, pincode = pincode, schoolName = schoolName, tenthBoardname = tenthBoardname,
                schoolPercentage = schoolPercentage, schoolPassingyear = schoolPassingyear, hscCollegeName = hscCollegeName,
                hscBoardName = hscBoardName, hscPercentage = hscPercentage,hscPassingyear= hscPassingyear, collegeName = collegeName, universityName = universityName,
                stream = stream, graduationPercentage = graduationPercentage, graduationPassingYear = graduationPassingYear,
                projectTitle = projectTitle, projectDetails = projectDetails, certification = certification };
               bool status = CandidateRegisterBusinessManager.insert(theCandidateRegister);
               if (status)
               {
                return this.RedirectToAction("index", "home");
               }

            return View();
        }

        public ActionResult Update(int id)
        {
            CandidateRegister theCandidateRegister = CandidateRegisterBusinessManager.GetById(id);
            return View(theCandidateRegister);
        }

        [HttpPost]
        public ActionResult Update(int id, string firstName, string lastName, string email, string password,
                string gender, DateTime dob, string canAddr, string phoneNum, string state,
                string city, string altEmail, int pincode, string schoolName, string tenthBoardname,
                double schoolPercentage, int schoolPassingyear, string hscCollegeName, string hscBoardName,
                double hscPercentage, int hscPassingyear, string collegeName, string universityName,
                 string stream, double graduationPercentage, int graduationPassingYear, string projectTitle,
                string projectDetails, string certification)
        {
            CandidateRegister theCandidateRegister = new CandidateRegister
            {
                candidateId = id,
                firstName = firstName,
                lastName = lastName,
                email = email,
                password = password,
                gender = gender,
                dob = dob,
                canAddr = canAddr,
                phoneNum = phoneNum,
                state = state,
                city = city,
                altEmail = altEmail,
                pincode = pincode,
                schoolName = schoolName,
                tenthBoardname = tenthBoardname,
                schoolPercentage = schoolPercentage,
                schoolPassingyear = schoolPassingyear,
                hscCollegeName = hscCollegeName,
                hscBoardName = hscBoardName,
                hscPercentage = hscPercentage,
                hscPassingyear = hscPassingyear,
                collegeName = collegeName,
                universityName = universityName,
                stream = stream,
                graduationPercentage = graduationPercentage,
                graduationPassingYear = graduationPassingYear,
                projectTitle = projectTitle,
                projectDetails = projectDetails,
                certification = certification


            };
            bool status = CandidateRegisterBusinessManager.Update(theCandidateRegister);
            if (status)
            {
                return this.RedirectToAction("canhome", "CandidateRegister");

            }
            return View();
        }


        public ActionResult Delete(int id)
        {
            bool status = CandidateRegisterBusinessManager.delete(id);
            if (status == true)
            {
                return this.RedirectToAction("index", "CandidateRegister");


            }
            return View();
        }

       

    }
}
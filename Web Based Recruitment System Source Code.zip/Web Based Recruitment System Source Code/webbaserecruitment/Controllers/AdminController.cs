﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BLL;
using BOL;

namespace webbaserecruitment.Controllers
{
    public class AdminController : Controller
    {
        // GET: Admin
        public ActionResult Index()
        {
            List<Admin> allAdmin = AdminBusinessManager.GetAllAdmin();

            this.ViewData["admin"] = allAdmin;
            return View();
        }

        public ActionResult Details(int id)
        {
            Admin theAdmin = AdminBusinessManager.GetById(id);

            return View(theAdmin);
        }


        public ActionResult Insert()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Insert( string firstName, string lastName,string email, string password)
        {
            Admin theAdmin= new Admin { firstName = firstName, lastName = lastName, email = email, password = password };
            bool status = AdminBusinessManager.insert(theAdmin);
            if (status)
            {
                return this.RedirectToAction("index", "Admin");
            }

            return View();
        }

        public ActionResult Update(int id)
        {
            Admin theAdmin = AdminBusinessManager.GetById(id);
            return View(theAdmin);
        }
        [HttpPost]
        public ActionResult Update(int id, string firstName, string lastName, string email, string password)
        {
            Admin theAdmin = new Admin
            {
                adminId = id,
                firstName = firstName,
                lastName = lastName,
                email = email,
                password = password
            };
            bool status = AdminBusinessManager.Update(theAdmin);
            if (status)
            {
                return this.RedirectToAction("index", "Admin");

            }
            return View();
        }

        public ActionResult Delete(int id)
        {
            bool status = AdminBusinessManager.delete(id);
            if (status == true)
            {
                return this.RedirectToAction("index", "Admin");


            }
            return View();
        }

        public ActionResult adhome()
        {
            if (TempData["adLogin"] != null)
            {
                List<RecruiterJobPost> allRecruiterJobPost = RecruiterJobPostBusinessManager.GetAllRecruiterJobPost();
                this.ViewData["recruiterJobPost"] = allRecruiterJobPost;

                List<RecruiterRegister> allRecruiterRegister = RecruiterRegisterBusinessManager.GetAllRecruiterRegister();
                this.ViewData["recruiterRegister"] = allRecruiterRegister;

                List<CandidateRegister> allCandidateRegister = CandidateRegisterBusinessManager.GetAllCandidateRegister();
                this.ViewData["candidateRegister"] = allCandidateRegister;

                Admin ad = new Admin();
                ad = (Admin)TempData["adLogin"];
                return View(ad);
            }
            else
            {
                return null;
            }
        }

    }
}
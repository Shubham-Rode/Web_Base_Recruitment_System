﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BLL;
using BOL;


namespace webbaserecruitment.Controllers
{
    public class AppliedJobPostController : Controller
    {
        // GET: AppliedJobPost
        public ActionResult Index()
        {
            List<AppliedJobPost> allAppliedJobPost = AppliedJobPostBusinessManager.GetAllAppliedJobPost();

            this.ViewData["appliedJobPost"] = allAppliedJobPost;
            return View();
        }

        public ActionResult Details(int id)
        {
            AppliedJobPost theAppliedJobPost = AppliedJobPostBusinessManager.GetById(id);

            return View(theAppliedJobPost);
        }

        public ActionResult Insert()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Insert(bool status, int candidateId, int jobId)
        {
            AppliedJobPost theAppliedJobPost = new AppliedJobPost { status = status, candidateId = candidateId, jobId = jobId};
            bool statuus = AppliedJobPostBusinessManager.insert(theAppliedJobPost);
            if (statuus)
            {
                return this.RedirectToAction("index", "AppliedJobPost");
            }

            return View();
        }

        public ActionResult Update(int id)
        {
            AppliedJobPost theAppliedJobPost = AppliedJobPostBusinessManager.GetById(id);

            return View(theAppliedJobPost);
        }
        [HttpPost]
        public ActionResult Update(int id, bool status, int candidateId, int jobId)
        {
            AppliedJobPost theAppliedJobPost = new AppliedJobPost
            {
                appliedId = id,
                status = status,
                candidateId = candidateId,
                jobId = jobId,

            };
            bool statuus = AppliedJobPostBusinessManager.Update(theAppliedJobPost);
            if (statuus)
            {
                return this.RedirectToAction("index", "AppliedJobPost");

            }
            return View();
        }


        public ActionResult Delete(int id)
        {
            bool status = AppliedJobPostBusinessManager.delete(id);
            if (status == true)
            {
                return this.RedirectToAction("index", "AppliedJobPost");


            }
            return View();
        }

    }
}
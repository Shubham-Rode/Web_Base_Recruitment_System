﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOL;
using DAL;

namespace BLL
{
    public class CandidateRegisterBusinessManager
    {
        public static List<CandidateRegister> GetAllCandidateRegister()
        {

            List<CandidateRegister> allCandidateRegister = new List<CandidateRegister>();
            allCandidateRegister = CandidateRegisterDBManager.GetAllCandidateRegister();
            return allCandidateRegister;
        }

        public static CandidateRegister GetById(int id)
        {
            CandidateRegister theCandidateRegister = new CandidateRegister();
            theCandidateRegister = CandidateRegisterDBManager.GetCandidateRegisterById(id);
            return theCandidateRegister;

        }


        public static bool insert(CandidateRegister newCandidateRegister)
        {
            bool status = CandidateRegisterDBManager.Insert(newCandidateRegister);
            return status;
        }

        public static bool Update(CandidateRegister theCandidateRegister)
        {
            return CandidateRegisterDBManager.update(theCandidateRegister);
        }

        public static bool delete(int id)
        {
            return CandidateRegisterDBManager.Delete(id);
        }

        public static CandidateRegister GetByEmailAndPassword(String email,String password)
        {
            CandidateRegister theCandidateLogin = new CandidateRegister();
            theCandidateLogin = CandidateRegisterDBManager.GetCandidateByEmailAndPassword(email,password);
            return theCandidateLogin;

        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOL;
using DAL;

namespace BLL
{
    public class CandidateWorkExperienceBusinessManager
    {

        public static List<CandidateWorkExperience> GetAllCandidateWorkExperience()
        {

            List<CandidateWorkExperience> allCandidateWorkExperience = new List<CandidateWorkExperience>();
            allCandidateWorkExperience = CandidateWorkExperienceDBManager.GetAllCandidateWorkExperience();
            return allCandidateWorkExperience;
        }

        public static List<CandidateWorkExperience> GetByCandidateId(int id)
        {
            List<CandidateWorkExperience> allCandidateWorkExperience = new List<CandidateWorkExperience>();
            allCandidateWorkExperience = CandidateWorkExperienceDBManager.GetCandidateWorkExperienceByCandidateId(id);
            return allCandidateWorkExperience;

        }

        public static bool insert(CandidateWorkExperience newCandidateWorkExperience)
        {
            bool status = CandidateWorkExperienceDBManager.Insert(newCandidateWorkExperience);
            return status;
        }

        public static bool Update(CandidateWorkExperience theCandidateWorkExperience)
        {
            return CandidateWorkExperienceDBManager.update(theCandidateWorkExperience);
        }

        public static bool delete(int id)
        {
            return CandidateWorkExperienceDBManager.Delete(id);
        }

        public static CandidateWorkExperience GetById(int id)
        {
            CandidateWorkExperience theCandidateWorkExperience = new CandidateWorkExperience();
            theCandidateWorkExperience = CandidateWorkExperienceDBManager.GetCandidateWorkExperienceById(id);
            return theCandidateWorkExperience;

        }

    }
}

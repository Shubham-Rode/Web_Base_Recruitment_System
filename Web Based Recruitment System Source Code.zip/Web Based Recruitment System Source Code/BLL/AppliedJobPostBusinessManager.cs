﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOL;
using DAL;

namespace BLL
{
    public class AppliedJobPostBusinessManager
    {

        public static List<AppliedJobPost> GetAllAppliedJobPost()
        {

            List<AppliedJobPost> allAppliedJobPost = new List<AppliedJobPost>();
            allAppliedJobPost = AppliedJobPostDBManager.GetAllAppliedJobPost();
            return allAppliedJobPost;
        }

        public static AppliedJobPost GetById(int id)
        {
            AppliedJobPost theAppliedJobPost = new AppliedJobPost();
            theAppliedJobPost = AppliedJobPostDBManager.GetAppliedJobPostById(id);
            return theAppliedJobPost;

        }

        public static bool insert(AppliedJobPost newAppliedJobPost)
        {
            bool status = AppliedJobPostDBManager.Insert(newAppliedJobPost);
            return status;
        }

        public static bool Update(AppliedJobPost theAppliedJobPost)
        {
            return AppliedJobPostDBManager.update(theAppliedJobPost);
        }

        public static bool delete(int id)
        {
            return AppliedJobPostDBManager.Delete(id);
        }

    }
}

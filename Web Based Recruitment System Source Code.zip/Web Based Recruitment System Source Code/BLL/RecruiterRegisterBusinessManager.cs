﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOL;
using DAL;

namespace BLL
{
    public class RecruiterRegisterBusinessManager
    {

        public static List<RecruiterRegister> GetAllRecruiterRegister()
        {

            List<RecruiterRegister> allRecruiterRegister = new List<RecruiterRegister>();
            allRecruiterRegister = RecruiterRegisterDBManager.GetAllRecruiterRegister();
            return allRecruiterRegister;
        }

        public static RecruiterRegister GetById(int id)
        {
            RecruiterRegister theRecruiterRegister = new RecruiterRegister();
            theRecruiterRegister = RecruiterRegisterDBManager.GetRecruiterRegisterById(id);
            return theRecruiterRegister;

        }

        public static bool insert(RecruiterRegister newRecruiterRegister)
        {
            bool status = RecruiterRegisterDBManager.Insert(newRecruiterRegister);
            return status;
        }

        public static bool Update(RecruiterRegister theRecruiterRegister)
        {
            return RecruiterRegisterDBManager.update(theRecruiterRegister);
        }

        public static bool delete(int id)
        {
            return RecruiterRegisterDBManager.Delete(id);
        }


        public static RecruiterRegister GetByEmailAndPassword (String email,String pass)
        {
            RecruiterRegister theRecruiterLogin = new RecruiterRegister();
            theRecruiterLogin = RecruiterRegisterDBManager.GetRecruiterByEmailAndPassword(email, pass);
            return theRecruiterLogin;
        }


    }
}

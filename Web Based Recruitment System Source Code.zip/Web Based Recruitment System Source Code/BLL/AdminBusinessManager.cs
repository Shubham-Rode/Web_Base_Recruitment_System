﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOL;
using DAL;

namespace BLL
{
    public class AdminBusinessManager
    {

        public static List<Admin> GetAllAdmin()
        {

            List<Admin> allAdmin = new List<Admin>();
            allAdmin = AdminDBManager.GetAllAdmin();
            return allAdmin;
        }

        public static Admin GetById(int id)
        {
            Admin theAdmin = new Admin();
            theAdmin = AdminDBManager.GetAdminById(id);
            return theAdmin;

        }

        public static bool insert(Admin newAdmin)
        {
            bool status = AdminDBManager.Insert(newAdmin);
            return status;
        }

        public static bool Update(Admin theAdmin)
        {
            return AdminDBManager.update(theAdmin);
        }

        public static bool delete(int id)
        {
            return AdminDBManager.Delete(id);
        }

        public static Admin GetByEmailAndPassword(String email,String pass)
        {
            Admin adminLogin = new Admin();
            adminLogin = AdminDBManager.GetRecruiterByEmailAndPassword(email, pass);
            return adminLogin;
        }


    }
}

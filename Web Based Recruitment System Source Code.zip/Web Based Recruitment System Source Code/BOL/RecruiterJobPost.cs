﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOL
{
    public class RecruiterJobPost
    {
        public int jobId { get; set; }

        public string jobTitle { get; set; }

        public string location { get; set; }

        public string remoteWork { get; set; }

        public string numberVacancy { get; set; }

        public string companyDescription { get; set; }

        public string industryType { get; set; }

        public string companySize { get; set; }

        public string employeementType { get; set; }

        public int minSalary { get; set; }

        public int maxSalary { get; set; }

        public string skillsRequired { get; set; }

        public int experienceRequired { get; set; }

        public string designation { get; set; }

        public DateTime postdate { get; set; }
        
        public int recruiterId { get; set; }


    }
}
